﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using RectificationOfDetailsPage.Models;
using System.ComponentModel.DataAnnotations.Schema;

namespace RectificationOfDetailsPage.Models
{
    public class Movie
    {
        public int MovieID { get; set; }
        [Display(Name ="Movie Name")]
        public string Name { get; set; }
        public int MovieTypeID { get; set; }

        public virtual MovieType MovieType { get; set; }

    }
}