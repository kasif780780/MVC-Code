﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using RectificationOfDetailsPage.Models;
     


namespace RectificationOfDetailsPage.Models
{
    public class MovieType
    {
        public int ID { get; set; }
        [Display(Name ="Movies Type")]
        public string Name { get; set; }


        public virtual ICollection<Movie> Movies { get; set; }
    }
}